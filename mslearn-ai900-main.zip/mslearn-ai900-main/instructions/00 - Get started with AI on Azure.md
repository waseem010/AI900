---
lab:
    title: 'Get started with artificial intelligence on Azure'
---

## Instructions
In this lab we will be looking at guidelines for Responsible AI.

1.	Go to [Guidelines for Human-AI Interaction demo](https://aka.ms/hci-demo)
2.	Pick cards from each deck and review the example scenarios
3.	Identify the Responsible AI principle(s) that the examples represent
