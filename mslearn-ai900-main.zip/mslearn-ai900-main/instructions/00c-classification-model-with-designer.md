---
lab:
    title: 'Create a Classification Model with Azure Machine Learning designer'
---

## Instructions
In this lab we will look at how to create classification models using Azure Machine Learning designer.

1.	Go to the Microsoft Learn module at https://docs.microsoft.com/learn/modules/create-classification-model-azure-machine-learning-designer/
